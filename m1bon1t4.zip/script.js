const btn = document.getElementById('toggleMusic');
const audio = document.getElementById('bgMusic');

btn.addEventListener('click', () => {
  if (audio.paused) {
    audio.play();
    btn.textContent = '🔇 Silenciar';
  } else {
    audio.pause();
    btn.textContent = '🎵 Música';
  }
});
